import vs

vs.kObjXPropHasUIOverride   = 8
vs.kObjXHasCustomWidgetVisibilities = 12

vs.kParametricRecalculate   = 3
vs.kObjOnInitXProperties    = 5
vs.kObjOnWidgetPrep         = 41
vs.kObjOnObjectUIButtonHit  = 35

vs.kObjectEventHandled      = -8

#Local constatns
kWidgetID_TotalHeight       = 1
kWidgetID_HeadShape         = 2
kWidgetID_Sex               = 3
kWidgetID_Hair              = 4
kWidgetID_HairLen           = 5
kWidgetID_DefaultHairLen    = 6

paramName = ''
paramHandle, paramRecHandle, wallHandle = 0, 0, 0

def execute():
    global paramName, paramHandle, paramRecHandle, wallHandle
    ok, paramName, paramHandle, paramRecHandle, wallHandle = vs.GetCustomObjectInfo( paramName, paramHandle, paramRecHandle, wallHandle )
    if paramHandle == 0:
        paramName = 'PythonSample_ObjectPt3'
        
    theEvent, theButton = None, None
    theEvent, theButton = vs.vsoGetEventInfo( theEvent, theButton )

    if theEvent == vs.kObjOnInitXProperties:
        # Enable custom shape pane
        ok = vs.SetObjPropVS( vs.kObjXPropHasUIOverride, True )
        ok = vs.SetObjPropVS( vs.kObjXHasCustomWidgetVisibilities, True )
    
        InitParameters()
    
    elif theEvent == vs.kObjOnWidgetPrep:
        UpdateParametersState()
    
    elif theEvent == vs.kObjOnObjectUIButtonHit:
        OnWidgetButtonHit( theButton )
    
    elif theEvent == vs.kParametricRecalculate:
        ResetEventHandler()
    
# this funciton is executed once and
# it defines the shape pane of the parametric object
#
# The shape pane is composed of widgets
# it is a widget connected to a parameter or it is a button widget
def InitParameters():
    # the following line will add all parameters as widgets
    # but we dont want that
    # we would like to set it up ourselves
    #ok = vs.vsoInsertAllParams()

    # add the widgets the way we like    
    ok = vs.vsoAddParamWidget( kWidgetID_TotalHeight, 'height', '' )
    ok = vs.vsoAddParamWidget( kWidgetID_HeadShape, 'Head Shape', '' )
    ok = vs.vsoAddParamWidget( kWidgetID_Sex, 'Sex', '' )
    ok = vs.vsoAddParamWidget( kWidgetID_Hair, 'Hair', '' )
    ok = vs.vsoAddParamWidget( kWidgetID_HairLen, 'Hair Length', '' )
    vs.vsoWidgetSetIndLvl( kWidgetID_HairLen, 1 )
    ok = vs.vsoAddWidget( kWidgetID_DefaultHairLen, 12, 'Reset Default' )
    vs.vsoWidgetSetIndLvl( kWidgetID_DefaultHairLen, 1 )

# this function updates the visibulity or enable/disable state of the wisgets
# note: keep this one fast, it is called often
def UpdateParametersState():
    vs.vsoWidgetSetVisible( kWidgetID_HairLen, vs.PHair )
    vs.vsoWidgetSetVisible( kWidgetID_DefaultHairLen, vs.PHair )
    vs.vsoWidgetSetEnable( kWidgetID_HairLen, vs.PSex == 'Female' )
    vs.vsoWidgetSetEnable( kWidgetID_DefaultHairLen, vs.PSex == 'Female' )
    
    # this is very important! this is how the system knows we've handled this
    vs.vsoSetEventResult( vs.kObjectEventHandled );


# this function handles button clicks from the shape pane
def OnWidgetButtonHit(theButton):
    if theButton == kWidgetID_DefaultHairLen:
        vs.AlrtDialog( 'Resetting Hair Length to its devalut value.' )
        vs.SetRField( paramHandle, 'PythonSample_ObjectPt3', 'Hair Length', '1' )
        vs.ResetObject( paramHandle )
    
# this function is executed when a parameter changes
# it will define the contents of the parametric object
# everything is created around (0,0) which will appear
# at the insertion poit of the parametric object in Vectorworks    
def ResetEventHandler():
    # precalculate height coeficient
    heightCoef = vs.Pheight / 67
    hairCoef = ( 1.5 - vs.PHair_Length / 2 )
    
    # generate the contents of the parametric object
    # around (0,0) which will be located
    # at the insertion point of the parametric in Vectorworks
    if vs.PHair:
        if vs.PSex == 'Female':
            vs.OpenPoly()
            vs.FillPat(0)
            vs.BeginPoly()
            vs.MoveTo(-0.231314385042733,0.96854751851328)
            vs.CurveTo(-0.266654510072474,1.028435530022942)
            vs.CurveTo(-0.380889689259427,1.006087566042448)
            vs.LineTo(-0.380889689259427,0.820015695259953 * hairCoef)
            vs.EndPoly()
            vs.SetVertexVisibility(vs.LNewObj(),3,False)
    
            vs.BeginPoly()
            vs.MoveTo(-0.089953884923948,1.075240285175172)
            vs.CurveTo(-0.089953884923948,1.127551685624274)
            vs.CurveTo(-0.188042050967459,1.127551685624274)
            vs.LineTo(-0.241570714765687,1.036841049174812 * hairCoef)
            vs.EndPoly()
            vs.SetVertexVisibility(vs.LNewObj(),3,False)
    
            vs.BeginPoly()
            vs.MoveTo(0.111989686674343,1.067337117274271)
            vs.CurveTo(0.111989686674343,1.125241556085172)
            vs.CurveTo(0.178409754777204,1.125241556085172)
            vs.LineTo(0.261620785767998,1.021643964159367 * hairCoef)
            vs.EndPoly()
            vs.SetVertexVisibility(vs.LNewObj(),3,False)
    
            vs.BeginPoly()
            vs.MoveTo(0.212961472473501,0.988305438265458)
            vs.CurveTo(0.263159595783576,1.109467917457901)
            vs.CurveTo(0.365136414913947,1.009695005994717)
            vs.LineTo(0.365136414913947,0.884988087228634 * hairCoef)
            vs.EndPoly()
            vs.SetVertexVisibility(vs.LNewObj(),3,False)
    
        else:
            vs.MoveTo(-0.23,0.97)
            vs.LineTo(-0.3,1.046)
    
            vs.MoveTo(-0.09,1.078)
            vs.LineTo(-0.115,1.15)
    
            vs.MoveTo(0.11,1.07)
            vs.LineTo(0.12,1.135)
    
            vs.MoveTo(0.21,0.99)
            vs.LineTo(0.25,1.069)
    
    if vs.PHead_Shape == 'Round':
        vs.FillPat(1)
        vs.Arc(-0.3,1.1,0.3,0.6,300,360)
    else:
        vs.ClosePoly()
        vs.Poly(
            0.246768187329414,0.64723858767505,
            0.299226699739776,0.64723858767505,
            0.299226699739776,0.995374273241997,
            0.230039127108626,0.995374273241997,
            0.230039127108626,1.034,
            0.163387002986838,1.034,
            0.163387002986838,1.088016456236655,
            -0.174,1.088016456236655,
            -0.174,0.995374273241997,
            -0.292591886036652,0.995374273241997,
            -0.292591886036652,0.64723858767505,
            -0.242665640208428,0.64723858767505,
            -0.242665640208428,0.6,
            0.246768187329414,0.6
        )
    
    
    # Body
    vs.MoveTo(0,0.6)
    vs.LineTo(0,-0.5 * heightCoef )
    
    # Amrs
    vs.MoveTo(0,0.3 * heightCoef)
    vs.LineTo(vs.PControlPoint01X, vs.PControlPoint01Y * heightCoef)
    
    vs.MoveTo(0,0.3 * heightCoef)
    vs.LineTo(vs.PControlPoint02X, vs.PControlPoint02Y * heightCoef)
    
    # Legs
    vs.MoveTo(0,-0.5 * heightCoef)
    vs.LineTo(vs.PControlPoint03X, vs.PControlPoint03Y * heightCoef)
    
    vs.MoveTo(0,-0.5 * heightCoef)
    vs.LineTo(vs.PControlPoint04X, vs.PControlPoint04Y * heightCoef)

    # Eyes
    vs.FillBack(0,0,0);
    vs.Arc(-0.1,0.9,-0.09,0.89,300,360)
    vs.Arc(0.09,0.9,0.1,0.89,240,360)
    
    # Mouth
    vs.ClosePoly()
    vs.FillBack(65535,65535,65535)
    vs.BeginPoly()
    vs.MoveTo(-0.152,0.748)
    vs.CurveTo(0,0.6)
    vs.LineTo(0.152,0.748)
    vs.CurveTo(0,0.6)
    vs.EndPoly()
    