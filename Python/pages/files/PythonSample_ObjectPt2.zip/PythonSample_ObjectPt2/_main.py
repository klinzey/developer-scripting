import vs

def execute():
    # deterimne the state of the parameters
    # on the shape pane
    vs.SetParameterVisibility( 0, 'ControlPoint03X', False )
    vs.SetParameterVisibility( 0, 'ControlPoint03Y', False )
    vs.SetParameterVisibility( 0, 'ControlPoint04X', False )
    vs.SetParameterVisibility( 0, 'ControlPoint04Y', False )
    vs.EnableParameter( 0, 'Disabled Parameter', False )
    
    # precalculate height coeficient
    heightCoef = vs.Pheight / 67
    
    # generate the contents of the parametric object
    # around (0,0) which will be located
    # at the insertion point of the parametric in Vectorworks
    if vs.PHair:
        if vs.PSex == 'Female':
            vs.OpenPoly()
            vs.FillPat(0)
            vs.BeginPoly()
            vs.MoveTo(-0.231314385042733,0.96854751851328)
            vs.CurveTo(-0.266654510072474,1.028435530022942)
            vs.CurveTo(-0.380889689259427,1.006087566042448)
            vs.LineTo(-0.380889689259427,0.820015695259953)
            vs.EndPoly()
            vs.SetVertexVisibility(vs.LNewObj(),3,False)
    
            vs.BeginPoly()
            vs.MoveTo(-0.089953884923948,1.075240285175172)
            vs.CurveTo(-0.089953884923948,1.127551685624274)
            vs.CurveTo(-0.188042050967459,1.127551685624274)
            vs.LineTo(-0.241570714765687,1.036841049174812)
            vs.EndPoly()
            vs.SetVertexVisibility(vs.LNewObj(),3,False)
    
            vs.BeginPoly()
            vs.MoveTo(0.111989686674343,1.067337117274271)
            vs.CurveTo(0.111989686674343,1.125241556085172)
            vs.CurveTo(0.178409754777204,1.125241556085172)
            vs.LineTo(0.261620785767998,1.021643964159367)
            vs.EndPoly()
            vs.SetVertexVisibility(vs.LNewObj(),3,False)
    
            vs.BeginPoly()
            vs.MoveTo(0.212961472473501,0.988305438265458)
            vs.CurveTo(0.263159595783576,1.109467917457901)
            vs.CurveTo(0.365136414913947,1.009695005994717)
            vs.LineTo(0.365136414913947,0.884988087228634)
            vs.EndPoly()
            vs.SetVertexVisibility(vs.LNewObj(),3,False)
    
        else:
            vs.MoveTo(-0.23,0.97)
            vs.LineTo(-0.3,1.046)
    
            vs.MoveTo(-0.09,1.078)
            vs.LineTo(-0.115,1.15)
    
            vs.MoveTo(0.11,1.07)
            vs.LineTo(0.12,1.135)
    
            vs.MoveTo(0.21,0.99)
            vs.LineTo(0.25,1.069)
    
    if vs.PHead_Shape == 'Round':
        vs.FillPat(1)
        vs.Arc(-0.3,1.1,0.3,0.6,300,360)
    else:
        vs.ClosePoly()
        vs.Poly(
            0.246768187329414,0.64723858767505,
            0.299226699739776,0.64723858767505,
            0.299226699739776,0.995374273241997,
            0.230039127108626,0.995374273241997,
            0.230039127108626,1.034,
            0.163387002986838,1.034,
            0.163387002986838,1.088016456236655,
            -0.174,1.088016456236655,
            -0.174,0.995374273241997,
            -0.292591886036652,0.995374273241997,
            -0.292591886036652,0.64723858767505,
            -0.242665640208428,0.64723858767505,
            -0.242665640208428,0.6,
            0.246768187329414,0.6
        )
    
    
    # Body
    vs.MoveTo(0,0.6)
    vs.LineTo(0,-0.5 * heightCoef )
    
    # Amrs
    vs.MoveTo(0,0.3 * heightCoef)
    vs.LineTo(vs.PControlPoint01X, vs.PControlPoint01Y * heightCoef)
    
    vs.MoveTo(0,0.3 * heightCoef)
    vs.LineTo(vs.PControlPoint02X, vs.PControlPoint02Y * heightCoef)
    
    # Legs
    vs.MoveTo(0,-0.5 * heightCoef)
    vs.LineTo(vs.PControlPoint03X, vs.PControlPoint03Y * heightCoef)
    
    vs.MoveTo(0,-0.5 * heightCoef)
    vs.LineTo(vs.PControlPoint04X, vs.PControlPoint04Y * heightCoef)

    # Eyes
    vs.FillBack(0,0,0);
    vs.Arc(-0.1,0.9,-0.09,0.89,300,360)
    vs.Arc(0.09,0.9,0.1,0.89,240,360)
    
    # Mouth
    vs.ClosePoly()
    vs.FillBack(65535,65535,65535)
    vs.BeginPoly()
    vs.MoveTo(-0.152,0.748)
    vs.CurveTo(0,0.6)
    vs.LineTo(0.152,0.748)
    vs.CurveTo(0,0.6)
    vs.EndPoly()
    