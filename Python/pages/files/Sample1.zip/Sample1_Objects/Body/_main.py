import random
import vs

vs.kObjXPropHasUIOverride   = 8
vs.kObjXHasCustomWidgetVisibilities = 12

vs.kParametricRecalculate   = 3
vs.kObjOnInitXProperties    = 5
vs.kObjOnWidgetPrep         = 41
vs.kObjOnObjectUIButtonHit  = 35

vs.kObjectEventHandled      = -8

#Local constants
kWidgetID_TotalHeight       = 1

paramName = ''
paramHandle, paramRecHandle, wallHandle = vs.Handle(), vs.Handle(), vs.Handle()



def execute():
    
##    Uncomment the following to run this code in debug mode
##    For more information refer to: http://developer.vectorworks.net/index.php/Python_Debugging
#     import pydevd
#     pydevd.settrace(suspend=False)
    
    global paramName, paramHandle, paramRecHandle, wallHandle
    ok, paramName, paramHandle, paramRecHandle, wallHandle = vs.GetCustomObjectInfo( paramName, paramHandle, paramRecHandle, wallHandle )
    if paramHandle == vs.Handle():
        paramName = 'PythonSample_ObjectPt3'
        
    theEvent, theButton = None, None
    theEvent, theButton = vs.vsoGetEventInfo( theEvent, theButton )

    if theEvent == vs.kObjOnInitXProperties:
        # Enable custom shape pane
        ok = vs.SetObjPropVS( vs.kObjXPropHasUIOverride, True )
        ok = vs.SetObjPropVS( vs.kObjXHasCustomWidgetVisibilities, True )
    
        InitParameters()
    
    elif theEvent == vs.kObjOnWidgetPrep:
        UpdateParametersState()
    
    elif theEvent == vs.kObjOnObjectUIButtonHit:
        OnWidgetButtonHit( theButton )
    
    elif theEvent == vs.kParametricRecalculate:
        ResetEventHandler()
    
# this funciton is executed once and
# it defines the shape pane of the parametric object
#
# The shape pane is composed of widgets
# it is a widget connected to a parameter or it is a button widget
def InitParameters():
    # the following line will add all parameters as widgets
    # but we dont want that
    # we would like to set it up ourselves
    #ok = vs.vsoInsertAllParams()

    # add the widgets the way we like    
    ok = vs.vsoAddParamWidget( kWidgetID_TotalHeight, 'height', '' )

    
    

# this function updates the visibulity or enable/disable state of the wisgets
# note: keep this one fast, it is called often
def UpdateParametersState():
   
    # this is very important! this is how the system knows we've handled this
    vs.vsoSetEventResult( vs.kObjectEventHandled );


# this function handles button clicks from the shape pane
def OnWidgetButtonHit(theButton):
   pass
    
# this function is executed when a parameter changes
# it will define the contents of the parametric object
# everything is created around (0,0) which will appear
# at the insertion poit of the parametric object in Vectorworks    
def ResetEventHandler():
    # precalculate height coeficient
    heightCoef = vs.Pheight / 67

    
    # generate the contents of the parametric object
    # around (0,0) which will be located
    # at the insertion point of the parametric in Vectorworks
    
	
    
       
    # Body
    vs.MoveTo(vs.PControlPoint05X,vs.PControlPoint05Y)
    vs.LineTo(0,-0.5 * heightCoef )
    
    # Amrs
    vs.MoveTo(0,0.3 * heightCoef)
    vs.LineTo(vs.PControlPoint01X, vs.PControlPoint01Y * heightCoef)
    
    vs.MoveTo(0,0.3 * heightCoef)
    vs.LineTo(vs.PControlPoint02X, vs.PControlPoint02Y * heightCoef)
    
    # Legs
    vs.MoveTo(0,-0.5 * heightCoef)
    vs.LineTo(vs.PControlPoint03X, vs.PControlPoint03Y * heightCoef)
    
    vs.MoveTo(0,-0.5 * heightCoef)
    vs.LineTo(vs.PControlPoint04X, vs.PControlPoint04Y * heightCoef)
    