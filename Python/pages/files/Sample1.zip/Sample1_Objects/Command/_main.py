import vs

def execute():

	vs.DSelectAll()
	current_layer = vs.ActLayer()
	if current_layer != None:
		current_object = vs.FInLayer( current_layer )		
		while current_object != None:
				vs.SetSelect(current_object)
				current_object = vs.NextObj( current_object )		
		vs.Group();
		current_layer = vs.NextLayer( current_layer )
 		
	
 	
	
		
	
	
	
		

    