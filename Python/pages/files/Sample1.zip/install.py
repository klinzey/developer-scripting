import shutil
import os
import vs

# Set a name for a better folder organization
plugin_name = "Sample1"

# Use negative number to get user path and positive number to get application path 
VW_USER_LIBARY_PATH = vs.GetFolderPath(-13)
VW_USER_WORKSPACE_PATH = vs.GetFolderPath(-4)
VW_USER_PLUGINs_PATH = vs.GetFolderPath(-2)

if not os.path.exists(os.path.join(VW_USER_LIBARY_PATH , plugin_name )):
    os.makedirs(os.path.join(VW_USER_LIBARY_PATH , plugin_name )) 

if not os.path.exists(os.path.join( VW_USER_WORKSPACE_PATH )):
    os.makedirs(os.path.join( VW_USER_WORKSPACE_PATH )) 

for file in os.listdir(VW_USER_PLUGINs_PATH):
    if file.endswith(".vww"):               													
	       shutil.move(os.path.join(VW_USER_PLUGINs_PATH , file ), os.path.join(VW_USER_WORKSPACE_PATH , file ))
    elif file.endswith(".vwx"):  
	       shutil.move(os.path.join(VW_USER_PLUGINs_PATH , file ), os.path.join(VW_USER_LIBARY_PATH , plugin_name, file ))