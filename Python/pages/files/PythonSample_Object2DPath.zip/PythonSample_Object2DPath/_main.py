import vs
from vector import *

def run():
    # Enable the pydev debugger
#    import pydevd
#    pydevd.settrace(suspend=False)

    objectName, objectHand, recordHand, wallHand = 0, 0, 0, 0
    ok, objectName, objectHand, recordHand, wallHand = vs.GetCustomObjectInfo( objectName, objectHand, recordHand, wallHand )
    if ok:
        hPath = vs.GetCustomObjectPath( objectHand )
        if hPath == 0:
            vs.FillPat(1)
            vs.Arc( (100,100), (-100,-100), 0, 360 )
        
        else:
            kSegmentCount = 10
            kDepth = 20
            
            arrLeftPoints = []
            arrRightPoints = []
        
            # generate the points    
            totalLen = vs.HPerim( hPath )
            stepLen = totalLen / kSegmentCount
            currLen = 0
            while ( currLen <= totalLen + 0.000001 ):
                pt = (0,0)
                tangent = (0,0)
                ok, pt, tangent = vs.PointAlongPoly( hPath, currLen, pt, tangent )
                
                if ok:
                    p = Vector( pt[0], pt[1] )
                    t = Vector( - tangent[1], tangent[0] )
                    
                    p0 = p - t * (kDepth/2)
                    p1 = p + t * (kDepth/2)
                    
                    arrLeftPoints.append( p0 )
                    arrRightPoints.append( p1 )
                 
                currLen += stepLen
                
                
            # generate the background
            vs.ClosePoly()
            vs.BeginPoly()
            for p in arrLeftPoints:
                vs.AddPoint( p.x, p.y )
            for p in reversed( arrRightPoints ):
                vs.AddPoint( p.x, p.y )
            vs.EndPoly()
            
            # generate steps
            for a,b in zip( arrLeftPoints, arrRightPoints ):
                vs.MoveTo( a.x, a.y )
                vs.LineTo( b.x, b.y )
            
if __name__ == "__main__":
    run()
    