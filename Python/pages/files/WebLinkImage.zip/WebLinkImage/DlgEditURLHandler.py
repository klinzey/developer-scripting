import vs
import DlgEditURL

dialog = 0
dialogData = ''

def DialogHandler(item, data):
    global dialogData
    
    if item == 12255: # Setup event
        vs.SetItemText( dialog, DlgEditURL.kURLEdit, dialogData )
        
    elif item == DlgEditURL.kURLEdit:
        dialogData = vs.GetMultilineText( dialog, DlgEditURL.kURLEdit, dialogData )

def RunDialog(webURL):
    global dialogData
    dialogData = webURL
    
    global dialog
    dialog = DlgEditURL.CreateDialog()
    
    ok = False
    if vs.RunLayoutDialog( dialog, DialogHandler ) == DlgEditURL.kOK:
        ok = True
    
    return ok, dialogData
