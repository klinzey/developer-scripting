import vs
import DlgEditWebLink
import DlgEditURLHandler
import DlgSaveNameHandler
import SavedWebLinks

class DialogData:
    url = ''
    address = ''
    arrParams = []
    
    def SetData(self, webURL):
        self.url = webURL
        self.address = ''
        self.arrParams = []
        
        arrUrlParts = webURL.split("&")
        if len(arrUrlParts) == 0:
            address = webURL
        else:
            arrUrlParts1 = arrUrlParts[ 0 ].split("?")
            if len(arrUrlParts1) != 0:
                self.address = arrUrlParts1[ 0 ]
                del arrUrlParts1[ 0 ]
                del arrUrlParts[ 0 ]
                
            for n in arrUrlParts1:
                self.arrParams.append( n )

            for n in arrUrlParts:
                self.arrParams.append( n )

    def RebuildURL(self):
        self.url = self.address
        if len(self.arrParams):
            self.url += "?"
            i = 0
            for param in self.arrParams:
                if len(param) > 0:
                    if i > 0: self.url += "&"
                    self.url += param
                i += 1

dialog = 0
dlgRestart = True
dlgData = DialogData()
savedLinks = SavedWebLinks.Data()

def FillSavedWLPopup():
    vs.DeleteAllItems( dialog, DlgEditWebLink.kSavedWLPPopup )
    
    selectItemIndex = 0
    itemIndex = 0
    vs.AddChoice( dialog, DlgEditWebLink.kSavedWLPPopup, vs.GetPluginString(4030), itemIndex )
    itemIndex += 1        
    
    for item in zip(savedLinks.arrNames, savedLinks.arrURLs):
        vs.AddChoice( dialog, DlgEditWebLink.kSavedWLPPopup, item[0], itemIndex )
        
        if item[1].lower() == dlgData.url.lower():
            selectItemIndex = itemIndex
            
        itemIndex += 1            
        
    vs.SelectChoice( dialog, DlgEditWebLink.kSavedWLPPopup, selectItemIndex, True )
    
    
def DialogHandler(item, data):
    global dlgRestart
    result = item
    
    if item == 12255: # Setup event
        vs.SetItemText( dialog, DlgEditWebLink.kAddresEdit, dlgData.address )
        
        # fill pre-sets
        FillSavedWLPopup()
        
        # fill parameters
        i = 0
        for param in dlgData.arrParams:
            vs.SetItemText( dialog, DlgEditWebLink.kParamEditCtrl + i, param )
            i += 1
        
    elif item == 12605: # The left button
        ok, newURL = DlgEditURLHandler.RunDialog( dlgData.url )
        if ok:
            dlgData.SetData( newURL )
            dlgRestart = True
            result = DlgEditWebLink.kCancel
            
    elif item == DlgEditWebLink.kAddresEdit:
        newAddress = vs.GetItemText( dialog, item, dlgData.address )
        
        if dlgData.address.lower() != newAddress.lower():
            vs.SelectChoice( dialog, DlgEditWebLink.kSavedWLPPopup, 0, True )
        
        dlgData.address = newAddress
        dlgData.RebuildURL()
            
    elif DlgEditWebLink.kParamEditCtrl <= item and item < DlgEditWebLink.kParamEditCtrl + len(dlgData.arrParams):
        paramIndex = (item - DlgEditWebLink.kParamEditCtrl)
        
        paramData = ''
        paramData = vs.GetItemText( dialog, item, paramData )
        
        if dlgData.arrParams[ paramIndex ].lower() != paramData.lower():
            vs.SelectChoice( dialog, DlgEditWebLink.kSavedWLPPopup, 0, True )
                 
        dlgData.arrParams[ paramIndex ] = paramData
        dlgData.RebuildURL()
        
    elif item == DlgEditWebLink.kAddMoreBtnCtrl:
        dlgData.arrParams.append( '' )
        dlgData.RebuildURL()
        dlgRestart = True
        result = DlgEditWebLink.kCancel
        
    elif item == DlgEditWebLink.kRemoveBntCtrl:
        if dlgData.arrParams:
            dlgData.arrParams.pop()
        dlgData.RebuildURL()
        dlgRestart = True
        result = DlgEditWebLink.kCancel
        
    elif item == DlgEditWebLink.kSavedWLPPopup:
        # we could have loaded the saved web link here
        # but VW wouldn't allow is to close the dialog at this point
        # so we go for additional button
        pass

    elif item == DlgEditWebLink.kLoadWLBtn:
        selIndex = -1
        selIndex = vs.GetSelectedChoiceIndex( dialog, DlgEditWebLink.kSavedWLPPopup, 0, selIndex )
        if selIndex > 0 and selIndex <= len(savedLinks.arrURLs): 
            dlgData.SetData( savedLinks.arrURLs[ selIndex - 1 ] ) # compensage one for the first reserved element
            
        dlgRestart = True
        result = DlgEditWebLink.kCancel
    
    elif item == DlgEditWebLink.kSaveWLBtn:
        ok, newName = DlgSaveNameHandler.RunDialog( vs.GetPluginString(4031) )
        if ok:
            savedLinks.arrNames.append( newName )
            savedLinks.arrURLs.append( dlgData.url )
            savedLinks.Save()
            
            vs.AddChoice( dialog, DlgEditWebLink.kSavedWLPPopup, newName, len(savedLinks.arrURLs) )
            
            vs.SelectChoice( dialog, DlgEditWebLink.kSavedWLPPopup, len(savedLinks.arrURLs), True )
    
    elif item == DlgEditWebLink.kDelWLBtn:
        if vs.AlertQuestion( vs.GetPluginString(4032), '', 0, vs.GetPluginString(4033), vs.GetPluginString(4034), '', '') == 1:
            
            selIndex = -1
            selIndex = vs.GetSelectedChoiceIndex( dialog, DlgEditWebLink.kSavedWLPPopup, 0, selIndex )
            if selIndex > 0 and selIndex <= len(savedLinks.arrURLs): 
                del savedLinks.arrNames[ selIndex - 1 ]  # compensage one for the first reserved element
                del savedLinks.arrURLs[ selIndex - 1 ]   # compensage one for the first reserved element
                savedLinks.Save()

                FillSavedWLPopup()

            
    return result
            

def RunDialog(webURL):
    dlgData.SetData( webURL )
    
    global dialog
    global dlgRestart
    
    result = False
    
    dlgRestart = True
    while dlgRestart:
        dlgRestart  = False
        dialog = DlgEditWebLink.CreateDialog( len(dlgData.arrParams) )
        if vs.RunLayoutDialog( dialog, DialogHandler ) == DlgEditWebLink.kOK:
            webURL = dlgData.url
            result = True
        
    return result, webURL

