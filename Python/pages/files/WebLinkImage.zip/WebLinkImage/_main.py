import vs
import os
import tempfile
import urllib.request

import DlgEditWebLinkHandler

vs.kObjXPropHasUIOverride   = 8
vs.kObjXHasCustomWidgetVisibilities = 12

vs.kParametricRecalculate   = 3
vs.kObjOnInitXProperties    = 5
vs.kObjOnWidgetPrep         = 41
vs.kObjOnObjectUIButtonHit  = 35

vs.kObjectEventHandled      = -8

#Local constatns
kWidgetID_ImageText         = 1
kWidgetID_WebLinkText       = 2
kWidgetID_EditWebLinkButton = 3
kWidgetID_UpdateButton      = 4

paramName = ''
paramHandle = vs.Handle()
paramRecHandle = vs.Handle()
wallHandle = vs.Handle()

def execute():
    global paramName, paramHandle, paramRecHandle, wallHandle
    ok, paramName, paramHandle, paramRecHandle, wallHandle = vs.GetCustomObjectInfo()
    if paramHandle == 0:
        paramName = 'Web Link Image'
        
    theEvent, theButton = vs.vsoGetEventInfo()

    if theEvent == vs.kObjOnInitXProperties:
        # Enable custom shape pane
        ok = vs.SetObjPropVS( vs.kObjXPropHasUIOverride, True )
        ok = vs.SetObjPropVS( vs.kObjXHasCustomWidgetVisibilities, True )
    
        InitParameters()
    
    elif theEvent == vs.kObjOnWidgetPrep:
        UpdateParametersState()
    
    elif theEvent == vs.kObjOnObjectUIButtonHit:
        OnWidgetButtonHit( theButton )
    
    elif theEvent == vs.kParametricRecalculate:
        ResetEventHandler()
    
# init the shape pane for this parametric
def InitParameters():
    ok = vs.vsoAddWidget( kWidgetID_ImageText, 13, vs.GetPluginString( 3000 ) )         # static text
    ok = vs.vsoAddParamWidget( kWidgetID_WebLinkText, 'WebRequest', '' )
    ok = vs.vsoAddWidget( kWidgetID_EditWebLinkButton, 12, vs.GetPluginString( 3001 ) ) # button
    ok = vs.vsoAddWidget( kWidgetID_UpdateButton, 12, vs.GetPluginString( 3002 ) )      # button

# this function updates the visibulity or enable/disable state of the wisgets
# note: keep this one fast, it is called often
def UpdateParametersState():
    pass
    
    # this is very important! this is how the system knows we've handled this
    vs.vsoSetEventResult( vs.kObjectEventHandled );


# this function handles button clicks from the shape pane
def OnWidgetButtonHit(theButton):
    if theButton == kWidgetID_EditWebLinkButton:
        ok, newWebRequest = DlgEditWebLinkHandler.RunDialog( vs.PWebRequest )
        if ok:
            vs.SetRField( paramHandle, 'Web Link Image', 'WebRequest', newWebRequest )
            vs.ResetObject( paramHandle )

    elif theButton == kWidgetID_UpdateButton:
        vs.ResetObject( paramHandle )
        
    
# this function is executed when a parameter changes
# it will define the contents of the parametric object
# everything is created around (0,0) which will appear
# at the insertion poit of the parametric object in Vectorworks    
def ResetEventHandler():
    if not(vs.GetParent( paramHandle ) == vs.Handle()):
        localFile = None
        try:
            #make a variable to hold the name of the file that was written to
            filePath = tempfile.gettempdir()
            filePath += os.sep
            filePath += "tempimage.bin"
            
            
            requestURL = urllib.request.Request( vs.PWebRequest, headers={'User-Agent' : "Magic Browser"} )
            response = urllib.request.urlopen( requestURL )
            
            #open a local file for writing
            localFile = open( filePath, "wb" )
     		
            #read from request while writing to file
            localFile.write( response.read() )
            localFile.close()
            localFile = None
     		     
            if vs.ImportImageFile( filePath, 0, 0 ) == vs.Handle():
                vs.CreateText( vs.GetPluginString( 3004 ) )
            
        except urllib.request.HTTPError as e:
            try:
                vs.CreateText( str(e.fp.read()) )
            except:
                vs.CreateText( str(e) )
            
        except urllib.request.URLError as e:
            vs.CreateText( str(e) )
            
        except IOError as e:
            vs.CreateText( str(e) )
        
        except:
            vs.CreateText( vs.GetPluginString( 3003 ) )
    
        finally:
            if localFile != None:
                localFile.close()
    else:
        vs.Rect( -1, -0.8, 1, 0.8 )
        
