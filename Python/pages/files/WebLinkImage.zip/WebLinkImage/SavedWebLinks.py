import vs
import os
import xml.dom.minidom

class Data:
    filePath = ''
    arrNames = []
    arrURLs = []
    
    def __init__(self):
        self.filePath = vs.GetFolderPath( -20 )
        if vs.GetVersion()[3] == 1:
        	self.filePath = self.filePath.replace(':','/').split('/',1)[1]
        self.filePath += 'SavedWebLinks.xml'

        try:
            dom = xml.dom.minidom.parse( self.filePath )
            arrLocalNames = dom.getElementsByTagName( 'Name' )
            arrLocalURLs = dom.getElementsByTagName( 'URL' )
            for nameNode, urlNode in zip(arrLocalNames, arrLocalURLs):
                n = ''
                u = ''
                try:
                    n = self.GetText( nameNode.childNodes )
                    u = self.GetText( urlNode.childNodes )
                except:
                    pass
                
                if len(n) > 0 and len(u) > 0:
                    self.arrNames.append( n )
                    self.arrURLs.append( u )
        
        except:
            self.arrNames = []
            self.arrURLs = []
        
    def GetText(self, nodelist):
        rc = []
        for node in nodelist:
            if node.nodeType == node.TEXT_NODE:
                rc.append(node.data)
        return ''.join(rc)
    
    def Save(self):
        #try:
            impl = xml.dom.minidom.getDOMImplementation()
    
            newDocNode = impl.createDocument( None, "data", None )
            for item in zip(self.arrNames, self.arrURLs):
                webLinkNode     = newDocNode.createElement( 'WebLink' )
                nameNode        = newDocNode.createElement( 'Name' )
                nameValueNode   = newDocNode.createTextNode( item[0] )
                urlNode         = newDocNode.createElement( 'URL' )
                urlValueNode    = newDocNode.createTextNode( item[1] )
            
                newDocNode.documentElement.appendChild( webLinkNode )
                webLinkNode.appendChild( nameNode )
                nameNode.appendChild( nameValueNode )
                webLinkNode.appendChild( urlNode )
                urlNode.appendChild( urlValueNode )
                
            f = open( self.filePath, "w" )
            try:
                f.write(newDocNode.toprettyxml(indent="  "))
            finally:
                f.close()
            
        #except:
            #os.remove( self.filePath )

if __name__ == "__main__":
    test = Data() 
    test.arrNames.append( 'newone' )
    test.arrURLs.append( 'newURL' )
    test.Save()