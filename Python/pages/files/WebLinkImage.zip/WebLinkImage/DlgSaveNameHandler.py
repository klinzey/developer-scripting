import vs
import DlgSaveName

dialog = 0
dialogData = ''

def DialogHandler(item, data):
    global dialogData
    
    if item == 12255: # Setup event
        vs.SetItemText( dialog, DlgSaveName.kNameEdit, dialogData )
        
    elif item == DlgSaveName.kNameEdit:
        dialogData = vs.GetItemText( dialog, DlgSaveName.kNameEdit, dialogData )

def RunDialog(name):
    global dialogData
    global dialog
    
    dialogData  = name
    dialog = DlgSaveName.CreateDialog()
    
    ok = False
    if vs.RunLayoutDialog( dialog, DialogHandler ) == DlgSaveName.kOK:
        ok = True
        
    return ok, dialogData

