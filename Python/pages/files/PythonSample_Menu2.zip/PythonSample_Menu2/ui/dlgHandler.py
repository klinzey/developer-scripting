import copy
import vs
import ui.dlg

class DialogData:
    operationValue = "default"
    operationValue1 = 0
    
dialog = 0
dialogData = None
    
def DialogHandler(item, data):
    if item == 12255: # Setup event
        vs.SetItemText( dialog, ui.dlg.kDataValue, dialogData.operationValue )
        pass
    
    elif item == ui.dlg.kOperationA: 
        vs.AlrtDialog( 'kOperation A' )
        
    elif item == ui.dlg.kOperationB: 
        vs.AlrtDialog( 'kOperation B' )
        
    elif item == ui.dlg.kOperationC: 
        vs.AlrtDialog( 'kOperation C' )
        
    elif item == ui.dlg.kDataValue:
        dialogData.operationValue = vs.GetItemText( dialog, ui.dlg.kDataValue, dialogData.operationValue )
        pass
    
    return item    

def RunDialog(dlgData):
    # make a copy of the dialog data
    # so the dialog will edit the copy
    global dialogData;
    #dialogData = DialogData()
    #dialogData.operationValue = dlgData.operationValue
    #dialogData.operationValue1 = dlgData.operationValue1
    dialogData = copy.copy( dlgData )
    
   
    global dialog
    dialog = ui.dlg.CreateDialog()
    result = False
    if vs.RunLayoutDialog( dialog, DialogHandler ) == ui.dlg.kOK:
        result = True
        
    return result
    