import os, time, psutil, datetime
import shutil
from tkinter import *
from tkinter.filedialog import askdirectory
from tkinter.filedialog import askopenfilename
from tkinter import messagebox
import json

class Settings_Json:
    file_nam = 'settings.json'
    
    # Dict KEY's
    path = 'path'
    script = 'script'
    vector_pth = 'vector_pth'         
    saveVWX = 'saveVWX' 
    contiTest = 'continue'
    logDel = 'logDel'
class OptionsDialog:
    def __init__(self):
        self.root = Tk()
        self.path = ''
        self.script = ''
        self.vector = ''
        self.saveVWX = False
        self.was_cnld = False
        self.contiTest = False
        self.logDel = False
        self.root.title('Process VWX Files Executing a Script')
        
        #=======================================================================
        # Define the dialog
        #=======================================================================
        def on_closing():
            if messagebox.askokcancel("Quit", "Do you want to quit?"):
                self.root.destroy()
                self.was_cnld = True

        self.root.protocol("WM_DELETE_WINDOW", on_closing)
        self.root.bind('<Escape>', lambda e: on_closing())
        Label(self.root, font="Verdana 8 bold", text="""
This tool will open each .vwx, .mcd and .sta files in the Traverse folder and execute the specified script
(.vs - VectorScript; .py - Python). It will use the provided Vectorworks executable. An 'Output'folder
will be created next to the executable that contains the processed files (space holders, or saved VWX 
files after the script execution). The 'Output' folder will be used to skip already processed files in the
Traverse folder. A 'Crashed Files'folder will be created next to the executable that contains the crashed
or timed out files. The log file will be shown as text at the end of the tool execution.""").grid(row=0, column=0, columnspan=3, sticky=E+W)
        Label(self.root, text="Traverse Recursively Folder: ").grid(row=1, column=0, sticky=W)
        self.entryPath = Entry(self.root, width=80)
        self.entryPath.grid(row=1, column=1, sticky=W)
        Button(self.root, text="Select...", command=self.onSelectPathButton).grid(row=1, column=2, sticky=W)
        
        Label(self.root, text="Execute Script: ").grid(row=2, column=0, sticky=W)
        self.entryScript = Entry(self.root, width=80)
        self.entryScript.grid(row=2, column=1, sticky=W)
        Button(self.root, text="Select...", command=self.onSelectScriptButton).grid(row=2, column=2, sticky=W)
        
        Label(self.root, text="Vectorworks: ").grid(row=3, column=0, sticky=W)
        self.entryVector = Entry(self.root, width=80)
        self.entryVector.grid(row=3, column=1, sticky=W)
        Button(self.root, text="Select...", command=self.onSelectVectorButton).grid(row=3, column=2, sticky=W)
        
        self.saveVWXCheckVar = IntVar()
        Checkbutton(self.root, text="Save VWX Files After Translation or Script Execution", variable=self.saveVWXCheckVar).grid(row=4, column=1, sticky=W)
        
        self.logCheckVar = IntVar(value=0)          # Deleting the log is off by default
        Checkbutton(self.root, text="Clear The Log File", variable=self.logCheckVar).grid(row=5, column=1, sticky=W)
        
        self.continueTestVar = IntVar(value=1)      # Continue Check Box is on by default
        Checkbutton(self.root, text="Continue From The Last Run", variable=self.continueTestVar).grid(row=6, column=1, sticky=W)
        
        Button(self.root, text="Process", command=self.onProcess).grid(row=7, column=1, sticky=E+W)
        
        Button(self.root, text="Cancel", command=self.onCancel).grid(row=7, column=2, sticky=W)
        
        self.load_settings()
        
        self.root.update()
        
    def run(self):
        self.root.wait_window(self.root)

    def onProcess(self):
        self.saveVWX = True if self.saveVWXCheckVar.get() == 1 else False        
        self.contiTest = True if self.continueTestVar.get() == 1 else False
        self.logDel = True if self.logCheckVar.get() == 1 else False
        self.path = self.entryPath.get()    # PW: Get the values from the editfields.
        self.script = self.entryScript.get()
        self.vector = self.entryVector.get()
        
        self.save_settings()
        
        self.root.destroy()
        
    def onCancel(self):
        self.root.destroy()
        self.was_cnld = True    

    def onSelectPathButton(self):
        self.path = askdirectory(
                            title="Select Folder to Process" )
        self.entryPath.delete(0,END)
        self.entryPath.insert(0,self.path)
        
    def onSelectScriptButton(self):
        self.script = askopenfilename(
                            title="Select Script to Run",
                            filetypes =(("Script Files", "*.vs;*.px;*.vss;*.py;*.txt"),("All Files","*.*")) )
        self.entryScript.delete(0,END)
        self.entryScript.insert(0,self.script)
    def onSelectVectorButton(self):
        self.vector = askopenfilename(
                            title="Select Vectorworks Executable",
                            filetypes =(("Executable", "*.exe"),("All Files","*.*")) )
        self.entryVector.delete(0,END)
        self.entryVector.insert(0,self.vector)
    
    def load_settings (self):
        if not os.path.exists(Settings_Json.file_nam):
            return        
        
        try:
            with open (Settings_Json.file_nam, 'r') as f:
                set_dic = json.load(f)                
                
                self.entryPath.insert(0, set_dic [Settings_Json.path] )
                self.entryScript.insert(0, set_dic [Settings_Json.script] )
                self.entryVector.insert(0, set_dic [Settings_Json.vector_pth] )
                self.saveVWXCheckVar.set (set_dic [Settings_Json.saveVWX])
                self.logCheckVar.set (set_dic [Settings_Json.logDel])
                self.continueTestVar.set (set_dic [Settings_Json.contiTest])

        except Exception as e:            
            print (e)
            print("line 135")
    def save_settings (self):
        set_dic = {}
        
        set_dic [Settings_Json.path] = self.path 
        set_dic [Settings_Json.script] = self.script
        set_dic [Settings_Json.vector_pth] = self.vector
        set_dic [Settings_Json.saveVWX] = 1 if self.saveVWX else 0
        set_dic [Settings_Json.logDel] = 0
        set_dic [Settings_Json.contiTest] = 1
        
        try:
            with open (Settings_Json.file_nam, 'w') as f:
                json.dump(set_dic, f, indent=4)
        except Exception as e:
            print (e)
            print("line 151")
        
    
def OpenFile():
    if sys.platform == 'darwin':
        print("osX version isn't ready")
        #===========================================
        # This section isn't finished yet!!!
        #currentDir      = r"/MyProjects/VWBuild"
        #kSearchPath     = r"/Volumes/FileTesting/File Testing/Input Files"
        #kOutputPath     = r"/MyProjects/TestFiles/VW2016/Output Files"
        #kVWExecutable   = currentDir + r"/Vectorworks 2017E.app/Contents/MacOS/Vectorworks"
        #kCommFile       = currentDir + r"/AutomationCommFile.txt"
        #kLog            = currentDir + r"/LogFile.txt"
        #============================================
    else:
        kVWExecutable   = os.path.abspath(optionsDlg.vector)                # Vectorworks path
        currentDir      = os.path.abspath(kVWExecutable).split(os.sep)        
        exeCutable        = currentDir[-1]
        currentDir        = kVWExecutable[:-len(exeCutable)]                    # Current path
        kSearchPath     = os.path.abspath(optionsDlg.path)                    # Input test file path
        kOutputPath     = currentDir + r"Output Files"            				# Output test file path
        kPluginPath        = currentDir + r"Plug-Ins"                            # Automation Plugin folder
        kCommFile       = currentDir + r"AutomationCommFile.txt"            # Automation control *.txt file
        kLog            = currentDir + r"LogFile.txt"                        # Log file if some file cause a crash
        kBadFolder      = currentDir + r"Crashed Files"                        # Copy of the files that caused a crash
    
 
    
    if not optionsDlg.contiTest == True:  #Remove Output Files, Crashed Files folders and AutomationCommfile.txt file
        if os.path.isdir(kOutputPath):
            shutil.rmtree(kOutputPath)
    
        if os.path.isdir(kCommFile):
            os.remove(kCommFile)
        
        if os.path.isdir(kBadFolder):
            shutil.rmtree(kBadFolder)
    
    if optionsDlg.logDel == True:       # Deleting the log file
        if os.path.isfile(kLog):
            os.remove(kLog)
        
    if not os.path.exists(kBadFolder):  # Creating empty Crashed Files folder
        os.makedirs(kBadFolder)
            
    def ValidateFileName(filePath):         # What type Vectorworks files to run
        name, ext = os.path.splitext( filePath )
        ext = ext.lower()
        result = False
        if len(name) > 0 and name[0] != '.':
            if ext == '.mcd':
                result = True
            elif ext == '.vwx':
                result = True
            elif ext == '.sta':
            	result = True
        
        return result
    def GetRunningVWPIDs():
        arrVW = []
        for y in psutil.pids():
            thisProcess = psutil.Process( y )
            try:
                name = thisProcess.name().lower()
                if name.find( 'vectorworks') != -1:
                    arrVW.append ( y )
                elif name.find( 'werfault') != -1:
                    arrVW.append ( y )
            except Exception as e:
                print(e, "line 221")
        return arrVW
        
    def KillRunningVW():
        try:
            for x in GetRunningVWPIDs():
                
                try:
                    p = psutil.Process( x )
                    p.kill()
                except Exception as e:
                	print("can't kill the following process...", e, " line 232 ")
                	pass
            
        except Exception as e:
            print("can't kill the following process...", e, " line 236 ")
            pass
    def StartNewVW(path):
        try:
            if sys.platform == 'darwin':
                path = path.replace( " ", "\ " )
                d = path + ' -ab -t AutomatedTester'
            else:
                path = '"' + path + '"'
                d = path + ' -ab -t AutomatedTester'
            o = os.popen(d, 'r')
        except Exception as e:
            print(e)
            print("line 249")
    
    def RestartNewVW(path):
        KillRunningVW()
        time.sleep(2)
        StartNewVW(path)
    def Traverser(kSearchPath, kOutputPath):
        fileDict = {}
        # build information about processed files
        for dirname, dirnames, filenames in os.walk(kOutputPath):
            for filename in filenames:
                if ValidateFileName( filename ):
                    filePath = os.path.join( dirname, filename )
                    trimFilePath = filePath[ len(kOutputPath): ]
                    fileDict[ trimFilePath ] = True
        arrFiles = []
        # traverse search path and do the files
        for dirname, dirnames, filenames in os.walk(kSearchPath):
            for filename in filenames:
                if ValidateFileName( filename ):
                    fileInPath = os.path.join( dirname, filename )
                    fileOutPath = kOutputPath + fileInPath[ len(kSearchPath) : ]
                    dirOutPath = os.path.dirname(fileOutPath)
                    trimFilePath = fileInPath[ len(kSearchPath): ]
                    if trimFilePath not in fileDict:
                        arrFiles.append((fileInPath, fileOutPath, dirOutPath))
        
        return arrFiles
    def logging(fileInPath):
        log = open(kLog, "a", encoding='utf8')
        log.write(fileInPath+"\n")
        log.close()
        
    def ExecuteFileOpenTests(kSearchPath, kCommFile, kVWExecutable,kOutputPath):
        arrFiles = Traverser(kSearchPath, kOutputPath)
        restartCounter = 0                    
        fileIndex = 0
        for fileInPath, fileOutPath, dirOutPath in arrFiles:
            print("Processing..." + str(fileInPath))
            progressPerc = 100 * (fileIndex / len(arrFiles)) 
            donePerc = ("%.2f" % progressPerc)
            print( str(donePerc),"% ", str(fileIndex) + "/" + str(len(arrFiles)))
            fileIndex += 1
            #create the Output folder
            if not os.path.exists(dirOutPath):
                os.makedirs(dirOutPath)
            try:
                os.remove(kCommFile)
            except:
            	pass
            try:
                # create a request file for WV
                file = open(kCommFile, "w", encoding='utf8')
                file.write("open_file\n")
                file.write(fileInPath)
                file.write("\n")
                if os.path.isfile (optionsDlg.script):
                    file.write("run_script_file\n")
                    file.write(os.path.abspath(optionsDlg.script))
                    file.write("\n")
                
                file.write("save_file\n")
                file.write(fileOutPath)
                file.write("\n")
                file.write("close_file\n")
                file.close()
                
                # make sure we have a fresh VW copy
                if restartCounter >= 5:
                    RestartNewVW( kVWExecutable )
                    restartCounter = 0
                else:
                    restartCounter += 1
                
                # wait for VW to process the request
                try: 
                    timeWaiting = 0               
                    while os.path.isfile(kCommFile):
                        time.sleep(5)
                        timeWaiting += 5

                        if timeWaiting >= 600:  # 10 min
                            RestartNewVW( kVWExecutable )
                            restartCounter = 0
                            # simulate output file so it doesn't go again on the same file
                            try:
                                os.remove(fileOutPath)
                            except Exception as e:
                                print(e)
                                print("line338")
                            file = open(fileOutPath, "w")
                            file.close()
                            #print(fileInPath)
                            #print ( 'File taking too long. Restarting VW!' )
                            logging(fileInPath)
                            shutil.copy( fileInPath, kBadFolder )
                            print(fileInPath, 'timeout', ' File taking too long. Restarting VW!')
                            break

                except Exception as e:
                    print(e)
                    print("line 350", fileInPath)
                    #vwlogger.AddFailure(kSearchPath, fileInPath, 'crash', vwlogger.GetCallstack())
                # replace the VW saved file with a dummy one to reduce disk usage  
                try:
                    backUp = os.path.join (dirOutPath, "VW Backup")
                    if optionsDlg.saveVWX == True:
                        if os.path.isdir(backUp):
                            shutil.rmtree(backUp)                
                        
                    else:
                        file = open(fileOutPath, "w")
                        file.close()     
                except Exception as e:
                    logging(fileInPath)
                    logging(e)
                    print("line 365", fileInPath)
                    print(e)
                    #vwlogger.AddFailure(kSearchPath, fileInPath, 'crash', vwlogger.GetCallstack())
            except Exception as e:
                logging(fileInPath)
                print("line 370", fileInPath)
                print(e)
                #vwlogger.AddFailure(kSearchPath, fileInPath, 'crash', vwlogger.GetCallstack())
    
    fileDict = {}
    
    def ExecuteFolderDiff(kSearchPath, kOutputPath):
        # build a dictionary with the original files
        for dirname, dirnames, filenames in os.walk(kSearchPath):
            for filename in filenames:
                if ValidateFileName(filename):
                    filePath = os.path.join( dirname, filename )
                    trimFilePath = filePath[ len(kSearchPath): ]
                    fileDict[ trimFilePath ] = filePath
                
                
        for dirname, dirnames, filenames in os.walk(kOutputPath):
            for filename in filenames:
                if ValidateFileName(filename):
                    filePath = os.path.join( dirname, filename )
                    trimFilePath = filePath[ len(kOutputPath): ]
                
                    try:
                        fileDict.pop( trimFilePath )
                    except:
                        pass
            
        arr = []
        for x in fileDict.keys():
            arr.append(fileDict[x])
    
        return arr
    
    def Execute(currentDir, kSearchPath, kOutputPath):
        logging( " " )
        logging( "				New Run" )
        logging( "				" + datetime.datetime.now().strftime("%b-%d-%Y %I:%M:%S:%p") )
        KillRunningVW()
        StartNewVW( kVWExecutable )
        ExecuteFileOpenTests(kSearchPath, kCommFile, kVWExecutable, kOutputPath)
        time.sleep( 1 )
        KillRunningVW()
    
        arrDifferences = ExecuteFolderDiff( kSearchPath, kOutputPath )
        
        
        # LogDifferences
        for fileName in sorted(arrDifferences):
            msg = ''
            try:
                msg = 'Missing file: ' + fileName
                print( msg )
                print("Run the test again without to change any option ( 'Continue From The Last Run' must be checked ) ")
            except Exception as e:
                msg = 'Missing file: ' + str(fileName.encode('utf-8'))
                print(e, msg )
                print("Run the test again without to change any option ( 'Continue From The Last Run' must be checked ) ")
            try:
                print(kSearchPath, fileName, 'missing', 'The file is missing in the output folder.')
                print("Run the test again without to change any option ( 'Continue From The Last Run' must be checked ) ")
            except Exception as e:
                print( e, kSearchPath, str(fileName.encode('utf-8')), 'missing', 'The file is missing in the output folder.')
                print("Run the test again without to change any option ( 'Continue From The Last Run' must be checked ) ")
    
    Execute(currentDir, kSearchPath, kOutputPath)
    logging("				Done!!! " + datetime.datetime.now().strftime("%b-%d-%Y %I:%M:%S:%p"))
    os.startfile( kLog )
    print("Done!!!")
    print("Check the log file for crashed or timed out files")
optionsDlg = OptionsDialog()
optionsDlg.run()


print ( 'path: ', optionsDlg.path )
print ( 'script: ', optionsDlg.script )
print ( 'vectorworks exe', optionsDlg.vector )
print ( 'saveVWX: ', optionsDlg.saveVWX )
print ( 'clear the log: ', optionsDlg.logDel )
print ( 'continueTest: ', optionsDlg.contiTest )
  
if not optionsDlg.was_cnld:
    OpenFile()
else:
    print ('Dialog was canceled.') # PW: Canceling the dialog did not stop the execution.
