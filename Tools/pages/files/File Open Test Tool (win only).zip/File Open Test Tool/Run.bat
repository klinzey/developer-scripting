@echo off
python\python.exe Test.py
pause
