import sys, os, time, datetime, shutil, subprocess
try:
    import psutil
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "psutil"])
    import psutil
from tkinter import *
from tkinter.filedialog import askdirectory, askopenfilename
from tkinter import messagebox
from tkinter import Entry, END
import json
if sys.platform == 'darwin':
    try:
        from AppKit import NSOpenPanel, NSApplication, NSModalResponseOK
    except ImportError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyobjc"])
        from AppKit import NSOpenPanel, NSApplication, NSModalResponseOK

class Settings_Json:
    file_nam = 'settings.json'
    path = 'path'
    script = 'script'
    vector_pth = 'vector_pth'
    saveVWX = 'saveVWX'
    contiTest = 'continue'
    logDel = 'logDel'

class OptionsDialog:
    def __init__(self):
        self.root = Tk()
        print("Tkinter root created")
        self.path = ''
        self.script = ''
        self.vector = ''
        self.saveVWX = False
        self.was_cnld = False
        self.contiTest = False
        self.logDel = False
        self.root.title('Process VWX Files Executing a Script')

        def on_closing():
            if messagebox.askokcancel("Quit", "Do you want to quit?"):
                self.root.destroy()
                self.was_cnld = True

        self.root.protocol("WM_DELETE_WINDOW", on_closing)
        self.root.bind('<Escape>', lambda e: on_closing())
        Label(self.root, font="Verdana 8 bold", text="""
This tool will open each .vwx, .mcd and .sta files in the Traverse folder and execute the specified script
(.vs - VectorScript; .py - Python). It will use the provided Vectorworks executable. An 'Output'folder
will be created next to the executable that contains the processed files (space holders, or saved VWX
files after the script execution). The 'Output' folder will be used to skip already processed files in the
Traverse folder. A 'Crashed Files'folder will be created next to the executable that contains the crashed
or timed out files. The log file will be shown as text at the end of the tool execution.""").grid(row=0, column=0, columnspan=3, sticky=E+W)
       
        Label(self.root, text="Traverse Recursively Folder: ").grid(row=1, column=0, sticky=W)
        self.entryPath = Entry(self.root, width=80)
        self.entryPath.grid(row=1, column=1, sticky=W)
        Button(self.root, text="Select...", command=self.onSelectPathButton).grid(row=1, column=2, sticky=W)
       
        Label(self.root, text="Execute Script: ").grid(row=2, column=0, sticky=W)
        self.entryScript = Entry(self.root, width=80)
        self.entryScript.grid(row=2, column=1, sticky=W)
        Button(self.root, text="Select...", command=self.onSelectScriptButton).grid(row=2, column=2, sticky=W)
       
        Label(self.root, text="Vectorworks: ").grid(row=3, column=0, sticky=W)
        self.entryVector = Entry(self.root, width=80)
        self.entryVector.grid(row=3, column=1, sticky=W)
        Button(self.root, text="Select...", command=self.onSelectVectorButton).grid(row=3, column=2, sticky=W)
       
        self.saveVWXCheckVar = IntVar()
        Checkbutton(self.root, text="Save VWX Files After Script Execution", variable=self.saveVWXCheckVar).grid(row=4, column=1, sticky=W)
       
        self.logCheckVar = IntVar(value=0)
        Checkbutton(self.root, text="Clear The Log File", variable=self.logCheckVar).grid(row=5, column=1, sticky=W)
       
        self.continueTestVar = IntVar(value=1)
        Checkbutton(self.root, text="Continue From The Last Run", variable=self.continueTestVar).grid(row=6, column=1, sticky=W)
       
        Button(self.root, text="Process", command=self.onProcess).grid(row=7, column=1, sticky=E+W)
        Button(self.root, text="Cancel", command=self.onCancel).grid(row=7, column=2, sticky=W)
       
        self.load_settings()
        self.root.update()

    def run(self):
        self.root.wait_window(self.root)

    def onProcess(self):
        self.saveVWX = bool(self.saveVWXCheckVar.get())
        self.contiTest = bool(self.continueTestVar.get())
        self.logDel = bool(self.logCheckVar.get())
        self.path = self.entryPath.get()
        self.script = self.entryScript.get()
        self.vector = self.entryVector.get()
        self.save_settings()
        self.root.destroy()
        if sys.platform == 'darwin':
            self.root.update()

    def onCancel(self):
        self.root.destroy()
        self.was_cnld = True
        print("Cancel clicked")

    def onSelectPathButton(self):
        self.path = askdirectory(title="Select Folder to Process")
        self.entryPath.delete(0, END)
        self.entryPath.insert(0, self.path)

    def onSelectScriptButton(self):
        if sys.platform == 'darwin':
            from AppKit import NSOpenPanel, NSApplication, NSModalResponseOK
            from Foundation import NSArray
            NSApplication.sharedApplication()
            panel = NSOpenPanel.openPanel()
            panel.setCanChooseFiles_(True)
            panel.setCanChooseDirectories_(False)
            panel.setAllowsMultipleSelection_(False)
            panel.setTitle_("Select Script to Run")
            panel.setAllowedFileTypes_(NSArray.arrayWithObjects_('vs', 'px', 'vss', 'py', 'txt', None))
            result = panel.runModal()
            if result == NSModalResponseOK:
                self.script = panel.URLs()[0].path()
            else:
                self.script = ''

        else:
            self.script = askopenfilename(
                title="Select Script to Run",
                filetypes=(("Script Files", "*.vs;*.px;*.vss;*.py;*.txt"), ("All Files", "*.*")))
        self.entryScript.delete(0, END)
        self.entryScript.insert(0, self.script)

    def onSelectVectorButton(self):
        if sys.platform == 'darwin':
            NSApplication.sharedApplication()
            panel = NSOpenPanel.openPanel()
            panel.setCanChooseFiles_(True)
            panel.setCanChooseDirectories_(False)
            panel.setAllowsMultipleSelection_(False)
            panel.setTitle_("Select Vectorworks Application")
            panel.setAllowedFileTypes_(['app'])
            result = panel.runModal()
            if result == NSModalResponseOK:
                app_path = panel.URLs()[0].path()
                if app_path and app_path.endswith('.app'):
                    self.vector = os.path.join(app_path, "Contents", "MacOS", "Vectorworks")
                else:
                    self.vector = ''
                    print("Error: Please select a valid .app bundle")
        else:
            self.vector = askopenfilename(
                title="Select Vectorworks Executable",
                filetypes=(("Executable", "*.exe"), ("All Files", "*.*")))
        self.entryVector.delete(0, END)
        self.entryVector.insert(0, self.vector)

    def load_settings(self):
        if not os.path.exists(Settings_Json.file_nam):
            return
        try:
            with open(Settings_Json.file_nam, 'r') as f:
                set_dic = json.load(f)
                self.entryPath.insert(0, set_dic.get(Settings_Json.path, ''))
                self.entryScript.insert(0, set_dic.get(Settings_Json.script, ''))
                self.entryVector.insert(0, set_dic.get(Settings_Json.vector_pth, ''))
                self.saveVWXCheckVar.set(set_dic.get(Settings_Json.saveVWX, 0))
                self.logCheckVar.set(set_dic.get(Settings_Json.logDel, 0))
                self.continueTestVar.set(set_dic.get(Settings_Json.contiTest, 1))
        except Exception as e:
            print(f"Error loading settings: {e}")

    def save_settings(self):
        set_dic = {
            Settings_Json.path: self.path,
            Settings_Json.script: self.script,
            Settings_Json.vector_pth: self.vector,
            Settings_Json.saveVWX: 1 if self.saveVWX else 0,
            Settings_Json.logDel: 1 if self.logDel else 0,
            Settings_Json.contiTest: 1 if self.contiTest else 0
        }
        try:
            with open(Settings_Json.file_nam, 'w') as f:
                json.dump(set_dic, f, indent=4)
        except Exception as e:
            print(f"Error saving settings: {e}")

def ValidateFileName(filePath):
    name, ext = os.path.splitext(filePath)
    ext = ext.lower()
    return len(name) > 0 and name[0] != '.' and ext in ('.mcd', '.vwx', '.sta')

def GetRunningVWPIDs():
    arrVW = []
    for pid in psutil.pids():
        try:
            process = psutil.Process(pid)
            name = process.name().lower()
            if 'vectorworks' in name or 'werfault' in name:
                arrVW.append(pid)
        except Exception as e:
            print(f"Error in GetRunningVWPIDs: {e}")
    return arrVW

def KillRunningVW():
    try:
        for pid in GetRunningVWPIDs():
            try:
                p = psutil.Process(pid)
                p.kill()
            except Exception as e:
                print(f"Can't kill process {pid}: {e}")
    except Exception as e:
        print(f"Error in KillRunningVW: {e}")

def StartNewVW(path):
    try:
        cmd = [path, "-ab", "-t", "AutomatedTester"]
        print(f"Starting Vectorworks with command: {' '.join(cmd)}")
        process = subprocess.Popen(cmd)
        time.sleep(5)
        return process.pid
    except Exception as e:
        print(f"Error in StartNewVW: {e}")
        return None

def RestartNewVW(path):
    KillRunningVW()
    time.sleep(5)
    return StartNewVW(path)

def is_process_running(pid):
    try:
        proc = psutil.Process(pid)
        return proc.is_running() and proc.status() != psutil.STATUS_ZOMBIE
    except psutil.NoSuchProcess:
        return False

def OpenFile():
    print("Starting file processing...")
    kVWExecutable = os.path.abspath(optionsDlg.vector)
    if sys.platform == 'darwin':
        currentDir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(kVWExecutable))))
    else:
        currentDir = os.path.dirname(kVWExecutable)
   
    kSearchPath = os.path.abspath(optionsDlg.path)
    kOutputPath = os.path.join(currentDir, "Output Files")
    kCommFile = os.path.join(currentDir, "AutomationCommFile.txt")
    kLog = os.path.join(currentDir, "LogFile.txt")
    kBadFolder = os.path.join(currentDir, "Crashed Files")

    if not optionsDlg.contiTest:
        if os.path.isdir(kOutputPath):
            shutil.rmtree(kOutputPath)
        if os.path.isdir(kCommFile):
            os.remove(kCommFile)
        if os.path.isdir(kBadFolder):
            shutil.rmtree(kBadFolder)
    if optionsDlg.logDel and os.path.isfile(kLog):
        os.remove(kLog)
    if not os.path.exists(kBadFolder):
        os.makedirs(kBadFolder)

    with open(kLog, "a", encoding='utf8') as log:
        log.write(f"File Open Log - Started at {datetime.datetime.now()}\n")
        log.write(f"Processing {kSearchPath} with {kVWExecutable}\n")
        log.write(f"Script: {optionsDlg.script}\n\n")

    KillRunningVW()
    pid = StartNewVW(kVWExecutable)
    if pid is None:
        print("Failed to launch Vectorworks initially")
        return

    def Traverser(kSearchPath, kOutputPath):
        fileDict = {}
        for dirname, _, filenames in os.walk(kOutputPath):
            for filename in filenames:
                if ValidateFileName(filename):
                    filePath = os.path.join(dirname, filename)
                    trimFilePath = os.path.relpath(filePath, kOutputPath)
                    fileDict[trimFilePath] = True
        arrFiles = []
        for dirname, _, filenames in os.walk(kSearchPath):
            for filename in filenames:
                if ValidateFileName(filename):
                    fileInPath = os.path.join(dirname, filename)
                    fileOutPath = os.path.join(kOutputPath, os.path.relpath(dirname, kSearchPath), filename)
                    dirOutPath = os.path.dirname(fileOutPath)
                    trimFilePath = os.path.relpath(fileInPath, kSearchPath)
                    if trimFilePath not in fileDict:
                        arrFiles.append((fileInPath, fileOutPath, dirOutPath))
        return arrFiles

    def logging(fileInPath, message=""):
        with open(kLog, "a", encoding='utf8') as log:
            log.write(f"{fileInPath}: {message}\n")

    arrFiles = Traverser(kSearchPath, kOutputPath)
    restartCounter = 0
    fileIndex = 0

    for fileInPath, fileOutPath, dirOutPath in arrFiles:
        print(f"Processing: {fileInPath}")
        progressPerc = 100 * (fileIndex / len(arrFiles))
        print(f"{progressPerc:.2f}% - {fileIndex}/{len(arrFiles)}")
        fileIndex += 1

        if not os.path.exists(dirOutPath):
            os.makedirs(dirOutPath)

        try:
            os.remove(kCommFile)
        except FileNotFoundError:
            pass

        with open(kCommFile, "w", encoding='utf8') as file:
            file.write("open_file\n")
            file.write(fileInPath + "\n")
            if os.path.isfile(optionsDlg.script):
                file.write("run_script_file\n")
                file.write(os.path.abspath(optionsDlg.script) + "\n")
            file.write("save_file\n")
            file.write(fileOutPath + "\n")
            file.write("close_file\n")

        if restartCounter >= 5:
            pid = RestartNewVW(kVWExecutable)
            restartCounter = 0
        elif not is_process_running(pid):
            pid = StartNewVW(kVWExecutable)
            restartCounter = 0
        else:
            restartCounter += 1
            time.sleep(5)

        if pid is None:
            print(f"Failed to launch Vectorworks for {fileInPath}")
            logging(fileInPath, "Failed to launch Vectorworks")
            shutil.copy(fileInPath, kBadFolder)
            continue

        timeWaiting = 0
        maxWait = 1200
        while os.path.isfile(kCommFile):
            crashed = False
            try:
                proc = psutil.Process(pid)
                status = proc.status()
                if status == psutil.STATUS_ZOMBIE or status == psutil.STATUS_DEAD or status == psutil.STATUS_STOPPED:
                    crashed = True
            except psutil.NoSuchProcess:
                crashed = True

            if crashed:
                print(f"Vectorworks (PID: {pid}) crashed while processing {fileInPath} after {timeWaiting}s")
                logging(fileInPath, "Vectorworks crashed or stopped unexpectedly")
                KillRunningVW()
                try:
                    #os.remove(kCommFile)
                    print(f"In a 'while' try to Cleaned up {kCommFile} after VW crash")
                except Exception as e:
                    print(f"Error cleaning up {kCommFile}: {e}")
                shutil.copy(fileInPath, kBadFolder)
                #pid = RestartNewVW(kVWExecutable)
                restartCounter = 0
                break

            time.sleep(5)
            timeWaiting += 5
            if timeWaiting >= maxWait:
                print(f"Timeout after {maxWait}s for {fileInPath}")
                logging(fileInPath, "Timeout - File took too long")
                KillRunningVW()
                try:
                    #os.remove(kCommFile)
                    print(f"in while if timeout try to Cleaned up {kCommFile} after timeout")
                except Exception as e:
                    print(f"Error cleaning up {kCommFile}: {e}")
                shutil.copy(fileInPath, kBadFolder)
                #pid = RestartNewVW(kVWExecutable)
                restartCounter = 0
                break

        if not os.path.isfile(kCommFile) and not optionsDlg.saveVWX:
            try:
                os.remove(fileOutPath)
                with open(fileOutPath, "w") as dummy_file:
                    pass
            except Exception as e:
                print(f"Error handling output file: {e}")

    KillRunningVW()
    print("File processing completed")
    if os.path.exists(kLog):
        try:
            if sys.platform == 'darwin':
                subprocess.run(["open", kLog])
            else:
                os.startfile(kLog)
        except Exception as e:
            print(f"Error opening log file: {e}")
    else:
        print("No log file created - all files processed successfully")

if __name__ == "__main__":
    try:
        optionsDlg = OptionsDialog()
        optionsDlg.run()
        if not optionsDlg.was_cnld:
            OpenFile()
        else:
            print("Dialog was canceled")
    except Exception as e:
        print(f"Error during execution: {e}")
